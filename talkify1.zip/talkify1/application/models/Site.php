<?php
class Site extends CI_Controller {

public function index()
	{
		echo 'Hello World';
	}
}