<style type="text/css">
#fb{
width:200px;
height:150px;
border:0.1em #333366 solid;
margin:0px 0px 0px 220px;
margin-top:-30px;
}
#fb1{
width:400px;
height:150px;
border:0.1em #333366 solid;
margin:0px 0px 0px 200px;
margin-top:-150px;
}
#fb2{
width:200px;
height:150px;
border:0.1em #333366 solid;
margin:0px 0px 0px 885px;
margin-top:-150px;
}
</style>
<div class="clear">
    </div>
    <div id="site_info">
        <p>
            Copyright <a href="#">Talkifi</a>. All Rights Reserved.
       </p>
		<!--<div id="fb">
		Have Some Questions?
		<input type="text" name="search" />Search
		Additonal Resources
		<br />
            <a href="#">Articles & Tutorials</a>. 
			<a href="#">Community Forum</a>.<br />
			<a href="#">Contact Support</a>.
 		</div>
		<center>
		<div id="fb1">
		<strong>your Accouant Usage.</strong><br />
		Sending limit 8000 per all time.1586 left all time<br />
		<strong>An Email marketting tip for you....</strong><br />
		You should design an email so that it will fit in the viewing area most email clients.
		A width of 650 pixels will fit in most email client windows.
		</div></center>
		<div id="fb2">
		<strong>Stay connected</strong><br />
			<a href="#">Knowing U Customer Leads....</a> 
			<a href="#">Emails List+Facebook custom..</a><br /><br />
			<a href="#"><img src="images/f.jpg" width="20px" height="20px" align="right"/></a>
			<a href="#"><img src="images/twi.png" width="25px" height="25px" align="right"/>
					 </a><br />
		</div>-->
	</div>
	
	
</body>
</html>
