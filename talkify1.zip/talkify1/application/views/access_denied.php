
<div class="grid_10">
            <div class="box round first">
                <h2>
                   Access Denied</h2>
                <div class="block">
						

<h1 style="color:#FF0000">Access Denied: Please contact Administrator.</h1>
				<a href="javascript:history.back();"> <=== Go back </a>						
                </div>
            </div>
            
        </div>
<script src="js/compose.js" type="text/javascript"></script>        
        <div class="clear">
        </div>
    </div>
