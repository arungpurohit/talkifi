<script type="text/javascript" src="js/sms.js"></script>
<div class="grid_10">
  <div class="box round first fullpage">
     <h2> SMS  </h2>
	  <div class="block ">
		<td width="730" >
			<div id="sms_tab">
			 <ul>
				<li><a href="#existing">Existing</a></li>
				<li><a href="#builtin">Built In</a></li>
				<li><a href="#newcreate">Create</a></li>
			</ul>
			<div id="existing">
					<div id="smsaccordion">
					<h3><a href="#">Welcome Message</a></h3>
					<div>
					<p>Mauris mauris ante, blandit et, ultrices a, suscipit eget, quam. Integer ut neque. </p>
					</div>
					<h3><a href="#">Thank you messages</a></h3>
					<div>
						<p>Sed non urna. Donec et ante. Phasellus eu ligula. Vestibulum sit amet purus. Vivamus hendrerit, dolor at aliquet laoreet, 							                         mauris turpis porttitor velit, faucibus interdum tellus libero ac justo. Vivamus non quam. In suscipit faucibus urna. </p>
					</div>
					<h3><a href="#">Wishes</a></h3>
					<div>
					<p>Nam enim risus, molestie et, porta ac, aliquam ac, risus. Quisque lobortis. Phasellus pellentesque purus in massa. Aenean in                       pede. Phasellus ac libero ac tellus pellentesque semper. Sed ac felis. Sed commodo, magna quis lacinia ornare, quam ante                       aliquam nisi, eu iaculis leo purus venenatis dui. </p>
					<ul>
						<li>List item one</li>
						<li>List item two</li>
						<li>List item three</li>
					</ul>
					</div>
					<h3><a href="#">Payment</a></h3>
					<div>
					<p>Cras dictum. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum ante                       ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aenean lacinia mauris vel est. </p><p>Suspendisse eu                       nisl. Nullam ut libero. Integer dignissim consequat lectus. Class aptent taciti sociosqu ad litora torquent per conubia nostra,                       per inceptos himenaeos. </p>
					</div>
					</div>
			</div>
			<div id="builtin">
				<div id="builtinaccordion">
					<h3><a href="#">Welcome Message</a></h3>
					<div>
					<p>Mauris mauris ante, blandit et, ultrices a, suscipit eget, quam. Integer ut neque. </p>
					</div>
					<h3><a href="#">Thank you messages</a></h3>
					<div>
					<p>Sed non urna. Donec et ante. Phasellus eu ligula. Vestibulum sit amet purus. Vivamus hendrerit, dolor at aliquet laoreet,                       mauris turpis porttitor velit, faucibus interdum tellus libero ac justo. Vivamus non quam. In suscipit faucibus urna. </p>
					</div>
					<h3><a href="#">Wishes</a></h3>
					<div>
					<p>Nam enim risus, molestie et, porta ac, aliquam ac, risus. Quisque lobortis. Phasellus pellentesque purus in massa. Aenean in                       pede. Phasellus ac libero ac tellus pellentesque semper. Sed ac felis. Sed commodo, magna quis lacinia ornare, quam ante                          aliquam nisi, eu iaculis leo purus venenatis dui. </p>
					<ul>
						<li>List item one</li>
						<li>List item two</li>
						<li>List item three</li>
					</ul>
					</div>
					<h3><a href="#">Payment</a></h3>
					<div>
					<p>Cras dictum. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum ante                       ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aenean lacinia mauris vel est. </p><p>Suspendisse eu                       nisl. Nullam ut libero. Integer dignissim consequat lectus. Class aptent taciti sociosqu ad litora torquent per conubia nostra,                          per inceptos himenaeos. </p>
					</div>
					</div>
			</div>
			<div id="newcreate">
				<table  border="0">
				  <tr>
						<td width="296">
						<table width="100%" class="form">
						<tr>
						<td>Template Name: <input type="text" name="smstemplate_name" /> </td>
					  </tr>
					  <tr>
						<td>SMS Content : <textarea id="newsms_content"></textarea></td>
					  </tr>
					  <tr>
						<td>Word Count : <input type="text" name="newsms_word_count" maxlength="3" size="3" value="135" /></td>
					  </tr>
					  <tr>
						<td><input type="submit" name="newsms_submit" class="btn" value="Create"/>&nbsp;
												<input type="reset" name="newsms_reset" class="btn" value="Reset"/>
						</td>
				  </tr>
				</table>
					
					</td>
						<td width="33">
						<ul>
							<li>$UserName$</li>
							<li>$FirstName$</li>
							<li>$LastName$</li>
							<li>$RepName$</li>
							<li>$CompanyName$</li>
							<li>$RepMobile$</li>
						</ul>
						</td>
					  </tr>
		</table>
				</div>
			</div>
	
	</td>
				</div>
	 </div>
</div>