    <link rel="stylesheet" type="text/css" href="css/jquery.jqplot.min.css" />
    <!--[if lt IE 9]><script language="javascript" type="text/javascript" src="js/jqPlot/excanvas.min.js"></script><![endif]-->
    <script language="javascript" type="text/javascript" src="js/jqPlot/jquery.jqplot.min.js"></script>
    <script type="text/javascript" src="js/jqPlot/plugins/jqplot.canvasTextRenderer.min.js"></script>
    <script type="text/javascript" src="js/jqPlot/plugins/jqplot.canvasAxisLabelRenderer.min.js"></script>
    <script language="javascript" type="text/javascript" src="js/jqPlot/plugins/jqplot.barRenderer.min.js"></script>
    <script language="javascript" type="text/javascript" src="js/jqPlot/plugins/jqplot.pieRenderer.min.js"></script>
    <script language="javascript" type="text/javascript" src="js/jqPlot/plugins/jqplot.categoryAxisRenderer.min.js"></script>
    <script language="javascript" type="text/javascript" src="js/jqPlot/plugins/jqplot.highlighter.min.js"></script>
    <script language="javascript" type="text/javascript" src="js/jqPlot/plugins/jqplot.pointLabels.min.js"></script>
    <script type="text/javascript" src="js/jqPlot/plugins/jqplot.donutRenderer.min.js"></script>
    <script type="text/javascript" src="js/jqPlot/plugins/jqplot.bubbleRenderer.min.js"></script>
    <!-- END: load jqplot -->
    <script src="js/charts.js" type="text/javascript"></script>
 		
		 <div class="grid_5">
        	<div class="box round">
        		 <h2> Charts</h2>
                 <div id="donuts-chart">
                    </div>
            </div>     
        </div>
      
        
        <div class="grid_5">
        	<div class="box round">
        		 <h2> Charts</h2>
                  <div id="bubble-chart">
                    </div>
            </div>     
        </div>
		
         <div class="grid_10">
        	<div class="box round first">
        		 <h2> Charts</h2>
                  <div id="bar-chart">
                    </div>
            </div>     
        </div>
        
        <div class="grid_10">
            <div class="box round">
                <h2> Charts</h2>
                <div class="block">
                    <div id="points-chart">
                    </div>
                </div>
            </div>
        </div>
        
        
        
       
		
        <div class="clear">
        </div>
		
    </div>
    <div class="clear">
   
	