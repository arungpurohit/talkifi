<div class="grid_10">
	<div class="box round first">
		<h2>Lead Information <div style="text-align: right; float: right; font-size: 13px; color: #444; padding-right: 10px;" > <a href="#">Back to Report Details</a> </div></h2>
		<div class="block">
			<table width="95%" cellspacing="0" cellpadding="0" border="0" align="centter">
				<tbody>
					<tr>
						<td>
							<!-- top right buttons -->
							<table width="100%" cellspacing="0" cellpadding="3" border="0">
								<tbody>
									<tr>
										<td align="right" style="width: 100%">
											<input type="button" value="Edit" name="Edit" />
											<input type="button" value="Duplicate" name="Duplicate" />
											<input type="button" value="Delete" name="Delete" />
										</td>
									</tr>
								</tbody>
							</table><!-- end of top right buttons -->
						</td>
					</tr><br><br>	
					<tr>
						<!-- left col -->
						<td valign="top" align="left">
							<table width="100%" cellspacing="0" cellpadding="3" border="0" style="border-bottom: 0;">
								<tbody>
									<tr valign="top">
										<td align="left">
											<table width="100%" cellspacing="0" cellpadding="0" border="0">
												<tbody>
													<!-- Contact Information -->
													<tr valign="top">
														<td style="padding: 5px">
															<div style="position: absolute; width: 300px;"></div>
															<table width="100%" cellspacing="0" border="0">
																<tbody>
																	<tr>
																		<td style="padding: 5px;">
																			<table width="100%" cellspacing="0" cellpadding="0" border="0">
																				<tbody>
																					<tr>
																						<td> </td>
																						<td> </td>
																						<td> </td>
																						<td align="right"> </td>
																					</tr>
																					<tr>
																						<td colspan="4">
																							<div style="float: left; font-weight: bold">
																								<b>Contact Information</b>
																							</div>
																						</td>
																					</tr>
																				</tbody>
																			</table>
																			<div style="width: auto; display: block;">
																				<table width="100%" cellpadding="0" cellpadding="0" border="0">
																					<tbody>
																						<tr style="height: 25px">
																							<td width="25%" align="left">
																								First Name
																							</td>
																							<td align="left">
																								Mr.
																								<span>portal contact</span>
																							</td>
																							<td width="25%" align="left">
																								Contact Id
																							</td>
																							<td width="25%" align="left">CON1</td>
																						</tr>
																						<tr style="height: 25px">
																							<td width="25%" align="left">
																								Last Name
																							</td>
																							<td align="left">
																								<span>test</span>
																							</td>
																							<td width="25%" align="left">
																								Office Phone
																							</td>
																							<td width="25%" align="left">453463332</td>
																						</tr>
																						<tr style="height: 25px">
																							<td width="25%" align="left">
																								Lead Source
																							</td>
																							<td align="left">
																								<span>None</span>
																							</td>
																							<td width="25%" align="left">
																								Home Phone
																							</td>
																							<td width="25%" align="left">45346390</td>
																						</tr>
																						<tr style="height: 25px">
																							<td width="25%" align="left">
																								Title
																							</td>
																							<td align="left">
																								<span>VP Sales</span>
																							</td>
																							<td width="25%" align="left">
																								Other Phone
																							</td>
																							<td width="25%" align="left">45346390</td>
																						</tr>
																						<tr style="height: 25px">
																							<td width="25%" align="left">
																								Department
																							</td>
																							<td align="left">
																								<span>Sales</span>
																							</td>
																							<td width="25%" align="left">
																								Fax
																							</td>
																							<td width="25%" align="left">45346390</td>
																						</tr>
																						<tr style="height: 25px">
																							<td width="25%" align="left">
																								Email
																							</td>
																							<td align="left">
																								<span>sales@sales.coms</span>
																							</td>
																							<td width="25%" align="left">
																								Birthdate
																							</td>
																							<td width="25%" align="left">30Aug2012</td>
																						</tr>
																						<tr style="height: 25px">
																							<td width="25%" align="left">
																								Assistant
																							</td>
																							<td align="left">
																								<span>Jon Devor</span>
																							</td>
																							<td width="25%" align="left">
																								Reports To
																							</td>
																							<td width="25%" align="left">Chris Cliene</td>
																						</tr>
																						<tr style="height: 25px">
																							<td width="25%" align="left">
																								Assistant Phone
																							</td>
																							<td align="left">
																								<span>35466433</span>
																							</td>
																							<td width="25%" align="left">
																								Secondary Email
																							</td>
																							<td width="25%" align="left">Chris@sales.com</td>
																						</tr>
																						<tr style="height: 25px">
																							<td width="25%" align="left">
																								Email Opt Out
																							</td>
																							<td align="left">
																								<span>No</span>
																							</td>
																							<td width="25%" align="left">
																								Do Not Call
																							</td>
																							<td width="25%" align="left">No</td>
																						</tr>
																						<tr style="height: 25px">
																							<td width="25%" align="left">
																								Reference
																							</td>
																							<td align="left">
																								<span>No</span>
																							</td>
																							<td width="25%" align="left">
																								Assigned To
																							</td>
																							<td width="25%" align="left">Administrators</td>
																						</tr>	
																						<tr style="height: 25px">
																							<td width="25%" align="left">
																								Created Time
																							</td>
																							<td align="left">
																								<span>2011-10-28 14:10:10</span>
																							</td>
																							<td width="25%" align="left">
																								Modified Time
																							</td>
																							<td width="25%" align="left">2012-09-28 14:10:10</td>
																						</tr>	
																					</tbody>
																				</table>
																			</div>
																		</td>
																	</tr>
																</tbody>
															</table>
														</td>
													</tr> <!-- End of Contact Information -->
													
													<!-- Address Information -->
													<tr valign="top">
														<td style="padding: 5px">
															<div style="position: absolute; width: 300px;"></div>
															<table width="100%" cellspacing="0" border="0">
																<tbody>
																	<tr>
																		<td style="padding: 5px;">
																			<table width="100%" cellspacing="0" cellpadding="0" border="0">
																				<tbody>
																					<tr>
																						<td> </td>
																						<td> </td>
																						<td> </td>
																						<td align="right"> </td>
																					</tr>
																					<tr>
																						<td colspan="4">
																							<div style="float: left; font-weight: bold">
																								<b>Address Information</b>
																							</div>
																						</td>
																					</tr>
																				</tbody>
																			</table>
																			<div style="width: auto; display: block;">
																				<table width="100%" cellpadding="0" cellpadding="0" border="0">
																					<tbody>
																						<tr style="height: 25px">
																							<td width="25%" align="left">
																								Mailing Street
																							</td>
																							<td align="left">
																								<span>Street 46</span>
																							</td>
																							<td width="25%" align="left">
																								Alternative Street
																							</td>
																							<td width="25%" align="left">Street 47</td>
																						</tr>
																						<tr style="height: 25px">
																							<td width="25%" align="left">
																								Mailing PO Box
																							</td>
																							<td align="left">
																								<span>Niway</span>
																							</td>
																							<td width="25%" align="left">
																								Alternative PO Box
																							</td>
																							<td width="25%" align="left">NIway</td>
																						</tr>
																						<tr style="height: 25px">
																							<td width="25%" align="left">
																								Mailing City
																							</td>
																							<td align="left">
																								<span>Niway City</span>
																							</td>
																							<td width="25%" align="left">
																								Alternative City
																							</td>
																							<td width="25%" align="left">Niway City</td>
																						</tr>
																						<tr style="height: 25px">
																							<td width="25%" align="left">
																								Mailing State
																							</td>
																							<td align="left">
																								<span>WC</span>
																							</td>
																							<td width="25%" align="left">
																								Alternative State
																							</td>
																							<td width="25%" align="left">WC</td>
																						</tr>
																						<tr style="height: 25px">
																							<td width="25%" align="left">
																								Mailing Postal Code
																							</td>
																							<td align="left">
																								<span>870009</span>
																							</td>
																							<td width="25%" align="left">
																								Alternative Postal Code
																							</td>
																							<td width="25%" align="left">870009</td>
																						</tr>
																						<tr style="height: 25px">
																							<td width="25%" align="left">
																								Mailing Country
																							</td>
																							<td align="left">
																								<span>India</span>
																							</td>
																							<td width="25%" align="left">
																								Alternative Country
																							</td>
																							<td width="25%" align="left">India</td>
																						</tr>
																						
																					</tbody>
																				</table>
																			</div>
																		</td>
																	</tr>
																</tbody>
															</table>
														</td>
													</tr> <!-- End of Address Information -->
													
													<!-- Comments Information -->
													<tr valign="top">
														<td style="padding: 5px">
															<div style="position: absolute; width: 300px;"></div>
															<table width="100%" cellspacing="0" border="0">
																<tbody>
																	<tr>
																		<td style="padding: 5px;">
																			<table width="100%" cellspacing="0" cellpadding="0" border="0">
																				<tbody>
																					<tr>
																						<td> </td>
																						<td> </td>
																						<td> </td>
																						<td align="right"> </td>
																					</tr>
																					<tr>
																						<td colspan="4">
																							<div style="float: left; font-weight: bold">
																								<b>Comments Information</b>
																							</div>
																						</td>
																					</tr>
																				</tbody>
																			</table>
																			<div style="width: auto; display: block;">
																				<table width="100%" cellpadding="0" cellpadding="0" border="0">
																					<tbody>
																						<tr style="height: 25px">
																							<td width="25%" align="left">
																								Comment
																							</td>
																							<td align="left">
																								<span>Test Comment</span>
																							</td>
																						</tr>
																					</tbody>
																				</table>
																			</div>
																		</td>
																	</tr>
																</tbody>
															</table>
														</td>
													</tr> <!-- End of Comments Information -->
												</tbody>
											</table>
										</td>
									</tr>
								</tbody>
							</table>
						</td> <!-- end of left col -->
						
						<!-- right col -->
						<td width="22%" valign="top" style="border-left: 1px dashed #cccccc; padding: 13px;">
							<table width="100%" cellspacing="0" cellpadding="5" border="0">
								<tbody>
									<tr>
										<td align="left"><b>Actions</b></td>
									</tr>
									<tr>
										<td align="left">Call</td>
									</tr>
									<tr>
										<td align="left">Send Email</td>
									</tr>
									<tr>
										<td align="left">Add Task</td>
									</tr>
									<tr>
										<td align="left">Add Note</td>
									</tr>
								</tbody>
							</table>
						</td>
					</tr>
					<tr>
						
					</tr>
				</tbody>
			</table>
		</div> <!-- end of block -->
	</div> <!-- end of box -->
</div> <!-- end of grid_10 -->