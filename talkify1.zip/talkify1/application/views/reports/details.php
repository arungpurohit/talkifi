
<div class="grid_10">
	<div class="box round first">
	<h2>Contacts by Organizations <div style="text-align: right; float: right; font-size: 13px; color: #444; padding-right: 10px;" > <a href="#">Back to Reports</a> </div></h2>
    	<div class="block">
			<div id="ajaxLoadAni">
    			<img src="http://localhost/talkify/images/ajax-loader.gif" alt="Ajax Loading Animation" />
    			<span>Loading...</span>
			</div>
			<div id="tabs">
				
				<table style="text-align: right; float: right;">
					<tr>
						<td valign="bottom" align="right" style="padding: 5px;" >
							<a href="#">Export to PDF</a> |
							<a href="#">Export to Excel</a>
						</td>
					</tr>
				</table>
    			<div id="read">
        			<table id="records">
            			<thead>
                			<tr>
			                    <th><input type="checkbox" name="vehicle" value="Bike" /></th>
			                    <th>SL. No</th>
			                    <th>First Name</th>
								<th>Last Name</th>
			                    <th>Source</th>
								<th>Organization Name</th>
								<th>Industry</th>
								<th>Email</th>
								<th>Action</th>
                			</tr>
							<br />
            			</thead>
            			<tbody>
			            	<tr id="1" class="odd">         
			            		<td class=" sorting_1"><input type="checkbox" name="checkAllCat1"></td>         
			            		<td>Denver</td>  
			            		<td>Jone</td>  
			            		<td>Cold Call</td>         
			            		<td>Shoba Devlopers</td>  
			            		<td>Real Estate</td> 
			            		<td>denver@shobadev.com</td>        
			            		<td><a href="#" class="updateBtn">View Details</a> </td>     
			            	</tr>
			            	<tr id="2" class="odd">         
			            		<td class=" sorting_1"><input type="checkbox" name="checkAllCat1"></td>         
			            		<td>Denver</td>  
			            		<td>Jone</td>  
			            		<td>Cold Call</td>         
			            		<td>Shoba Devlopers</td>  
			            		<td>Real Estate</td> 
			            		<td>denver@shobadev.com</td>        
			            		<td><a href="#" class="updateBtn">View Details</a> </td>     
			            	</tr>
			            	<tr id="3" class="odd">         
			            		<td class=" sorting_1"><input type="checkbox" name="checkAllCat1"></td>         
			            		<td>Denver</td>  
			            		<td>Jone</td>  
			            		<td>Cold Call</td>         
			            		<td>Shoba Devlopers</td>  
			            		<td>Real Estate</td> 
			            		<td>denver@shobadev.com</td>        
			            		<td><a href="#" class="updateBtn">View Details</a> </td>     
			            	</tr>
			            </tbody>
        			</table>
    			</div>
			</div> <!-- end tabs -->
			<!--<script type="text/javascript" src="http://localhost/talkify/js/inbox.js"></script>-->			
		</div>
	</div>     
</div><!-- End of grid10 -->
<div class="clear"></div>
